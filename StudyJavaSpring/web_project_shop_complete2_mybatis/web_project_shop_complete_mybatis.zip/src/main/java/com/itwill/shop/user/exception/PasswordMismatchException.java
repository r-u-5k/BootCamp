package com.itwill.shop.user.exception;

public class PasswordMismatchException extends Exception {
	public PasswordMismatchException() {
		// TODO Auto-generated constructor stub
	}
	public PasswordMismatchException(String msg) {
		super(msg);
	}
}
