package com.itwill.shop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebProjectShopCompleteApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebProjectShopCompleteApplication.class, args);
	}

}
